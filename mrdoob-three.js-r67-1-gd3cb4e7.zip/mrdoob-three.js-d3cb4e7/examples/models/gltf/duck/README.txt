---UPDATED 2/21/2007
Scaled down the duck to a more reasonable size, removed physics scene, removed extra "dummy" transforms and pivot points, added camera and light.
---

This model is a typical bathtub rubber duck.  It uses a single texture.

One version uses a polylist the other is triangles only.

The model has been stripped of all <extra> tags and should be COLLADA 1.4.1 compliant.

For additional information post messages on www.collada.org or mail collada@collada.org

These models are Copyright 2006 Sony Computer Entertainment Inc. and are distributed under the terms of the SCEA Shared Source License, available at http://research.scea.com/scea_shared_source_license.html